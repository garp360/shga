angular.module('hb.smartcard')

.directive("rightGutter",function(){
  return{
    link:function(scope,element){
    	if(scope.infoWindowIsShowing) {
    		element[0].style.paddingRight = scope.gutterWidth;
    	} else {
    		element[0].style.paddingRight = scope.defaultWidth;
    	}
    }        
  };    
});