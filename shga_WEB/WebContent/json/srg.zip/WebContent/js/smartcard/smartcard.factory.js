angular.module('hb.smartcard.factory.SmartCard', [])

.factory('SmartCardFactory', function ( $firebase , $q , $log, $timeout )
{
	var factory = {};
	
	var smartcards = [
	  {procedure: "SM1", category: "SM1-Category", surgeon: "SRG1"},
	  {procedure: "SM2", category: "SM2-Category", surgeon: "SRG2"},
	  {procedure: "SM3", category: "SM3-Category", surgeon: "SRG3"},
	  {procedure: "SM4", category: "SM4-Category", surgeon: "SRG4"},
	  {procedure: "SM5", category: "SM5-Category", surgeon: "SRG5"},
	  {procedure: "SM6", category: "SM6-Category", surgeon: "SRG6"},
	  {procedure: "SM7", category: "SM7-Category", surgeon: "SRG7"}];
	
	factory.findAll = function findAll() 
	{
		return smartcards;
	};
	
	return factory;
});