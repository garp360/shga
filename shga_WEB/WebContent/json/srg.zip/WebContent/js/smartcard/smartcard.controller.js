angular.module('hb.smartcard.controller.SmartCard', [])

.controller("SmartCardViewer", [ "$rootScope", "$scope", "$firebase", "$log", "$location", "SmartCardFactory", function($rootScope, $scope, $firebase, $log, $location, SmartCardFactory) {
	$scope.isloaded = false;
	$scope.defaultWidth = '0px';
	$scope.gutterWidth = '400px';
	$scope.infoWindowIsShowing = false;
	$scope.smartcards = SmartCardFactory.findAll();
	
	$scope.title = function(smartcard) {
		return smartcard.procedure + '::' + smartcard.surgeon;
	};
}]);